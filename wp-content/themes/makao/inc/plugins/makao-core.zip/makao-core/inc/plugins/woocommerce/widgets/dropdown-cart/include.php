<?php

include_once MAKAO_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/dropdown-cart.php';