<?php

include_once MAKAO_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list/variations/info-on-image/info-on-image.php';