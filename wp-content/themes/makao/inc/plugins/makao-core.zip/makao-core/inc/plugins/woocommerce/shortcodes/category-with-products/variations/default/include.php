<?php

include_once MAKAO_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/category-with-products/variations/default/helper.php';