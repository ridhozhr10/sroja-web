<?php

include_once MAKAO_CORE_INC_PATH . '/opener-icon/helper.php';