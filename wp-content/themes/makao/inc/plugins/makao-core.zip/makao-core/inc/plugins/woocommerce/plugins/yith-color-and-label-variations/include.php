<?php

include_once MAKAO_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-color-and-label-variations/helper.php';