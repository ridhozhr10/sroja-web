(function ($) {
	
    "use strict";
	qodefCore.shortcodes.makao_core_portfolio_list = {};
	qodefCore.shortcodes.makao_core_portfolio_list.qodefPagination = qodef.qodefPagination;
	qodefCore.shortcodes.makao_core_portfolio_list.qodefFilter = qodef.qodefFilter;
	qodefCore.shortcodes.makao_core_portfolio_list.qodefJustifiedGallery = qodef.qodefJustifiedGallery;
	qodefCore.shortcodes.makao_core_portfolio_list.qodefMasonryLayout = qodef.qodefMasonryLayout;

})(jQuery);