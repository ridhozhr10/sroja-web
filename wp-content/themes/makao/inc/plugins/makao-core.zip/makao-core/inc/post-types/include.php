<?php

include_once MAKAO_CORE_CPT_PATH . '/post-types.php';