<?php

include_once MAKAO_CORE_INC_PATH . '/icons/dripicons/dripicons.php';