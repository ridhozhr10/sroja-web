<?php

include_once MAKAO_CORE_INC_PATH . '/back-to-top/helper.php';
include_once MAKAO_CORE_INC_PATH . '/back-to-top/dashboard/admin/back-to-top-options.php';