<?php

include_once MAKAO_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/standard/standard.php';