<?php
include_once MAKAO_CORE_INC_PATH . '/core-dashboard/sub-pages/import/import-page.php';
include_once MAKAO_CORE_INC_PATH . '/core-dashboard/sub-pages/import/import.php';