<?php

include_once MAKAO_CORE_INC_PATH . '/media/helper.php';