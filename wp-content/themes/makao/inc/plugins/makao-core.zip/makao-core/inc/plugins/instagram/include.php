<?php

include_once MAKAO_CORE_PLUGINS_PATH . '/instagram/helper.php';