<?php

include_once MAKAO_CORE_INC_PATH . '/icons/material-icons/material-icons.php';