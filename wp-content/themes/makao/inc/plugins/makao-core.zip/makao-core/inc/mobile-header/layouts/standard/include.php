<?php

include_once MAKAO_CORE_INC_PATH . '/mobile-header/layouts/standard/helper.php';
include_once MAKAO_CORE_INC_PATH . '/mobile-header/layouts/standard/standard-mobile-header.php';
include_once MAKAO_CORE_INC_PATH . '/mobile-header/layouts/standard/dashboard/admin/standard-mobile-header-options.php';