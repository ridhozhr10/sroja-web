<?php

include_once MAKAO_CORE_INC_PATH . '/content/helper.php';