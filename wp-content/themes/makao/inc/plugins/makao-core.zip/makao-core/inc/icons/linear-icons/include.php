<?php

include_once MAKAO_CORE_INC_PATH . '/icons/linear-icons/linear-icons.php';