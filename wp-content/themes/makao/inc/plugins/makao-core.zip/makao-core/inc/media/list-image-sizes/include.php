<?php

include_once MAKAO_CORE_INC_PATH . '/media/list-image-sizes/list-image-sizes.php';