<?php

include_once MAKAO_CORE_INC_PATH . '/icons/elegant-icons/elegant-icons.php';