<?php

include_once MAKAO_CORE_INC_PATH . '/icons/linea-icons/linea-icons.php';